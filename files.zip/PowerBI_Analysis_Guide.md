# Power BI Analysis Guide

## 1. Import Data

- Open Power BI Desktop.
- Get Data > CSV > Select `pharma_sales_sample.csv`.

## 2. Data Preparation

- Check data types (Date, Text, Number).
- Create calculated fields if needed (e.g., Avg. Selling Price).

## 3. Building the Dashboard

- **Map Visualization:** Show Revenue or Units Sold by Country/Region.
- **Bar/Column Charts:** Sales by Product, Channel, or Sales Rep.
- **Line Chart:** Trend of Revenue over time.
- **Slicers:** Allow filtering by Product, Region, Channel.

## 4. Interactivity

- Enable drill-down features for more detailed analysis.
- Add filters for time, product, and region.

## 5. Insights

- Use the visualizations to identify trends, outliers, and opportunities.

## 6. Export

- Save your Power BI dashboard as a `.pbix` file.
- Publish your Power BI dashboard to Power BI Service (optional for public portfolio).