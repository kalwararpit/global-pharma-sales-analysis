# Global Pharma Sales Data Analysis

A business analyst portfolio project analyzing global pharmaceutical sales using Excel and Power BI.

## Project Overview

This project demonstrates end-to-end sales data analysis for a global pharmaceutical company, including data cleaning, exploration, visualization, forecasting, and actionable recommendations.

**Tools Used:**  
- Excel (for cleaning, pivot tables, and basic visualization)  
- Power BI (for interactive dashboards)  

## Contents

- `pharma_sales_sample.csv`: Sample dataset used for analysis.
- `Excel_Analysis_Guide.md`: Step-by-step instructions for analysis in Excel.
- `PowerBI_Analysis_Guide.md`: Step-by-step guide for Power BI dashboard creation.
- `Insights_and_Recommendations.md`: Business insights and suggested actions based on data.

## How to Use

1. Download or clone this repository.
2. Open `pharma_sales_sample.csv` in Excel or Power BI.
3. Follow the guides to replicate the analysis and create your own dashboards.
4. Review the insights and recommendations for business impact.

---

## License

This project is for demonstration and educational purposes.