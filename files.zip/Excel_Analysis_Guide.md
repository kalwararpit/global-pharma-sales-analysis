# Excel Analysis Guide

## 1. Load the Data

- Open `pharma_sales_sample.csv` in Excel.

## 2. Data Cleaning

- Check for missing values (use `Filter` or `ISBLANK`).
- Ensure date, region, and numeric columns are correctly formatted.

## 3. Exploratory Data Analysis

- Insert a Pivot Table (Insert > Pivot Table).
- Analyze sales by:
  - Region (`Rows`) and Revenue (`Values`)
  - Product (`Rows`) and Units Sold (`Values`)
  - Month (`Rows`, group by month from `Date`) and Revenue (`Values`)

## 4. Visualizations

- Create charts (bar, column, line) from Pivot Table results.
- Example: Sales by region, monthly revenue trends, top products.

## 5. Sales Forecasting

- Use a line chart with trendline (right-click line > Add Trendline).
- Use `FORECAST.LINEAR` to predict future revenue.

## 6. Export and Document

- Save your Excel with Pivot Tables and charts for your portfolio.